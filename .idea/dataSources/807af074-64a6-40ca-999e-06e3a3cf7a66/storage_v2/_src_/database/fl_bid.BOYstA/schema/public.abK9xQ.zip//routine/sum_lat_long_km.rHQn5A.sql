create function sum_lat_long_km(latbegin double precision, lngbegin double precision, latend double precision, lngend double precision) returns double precision
    language plpgsql
as
$$
DECLARE
  DECLARE Distance FLOAT;
  DECLARE EARTH_RADIUS FLOAT;
	DECLARE RadLatBegin FLOAT;	
	DECLARE RadLatEnd FLOAT;	
	DECLARE RadLatDiff FLOAT;	
	DECLARE RadLngDiff FLOAT;	
BEGIN
  --UNIT KM
  EARTH_RADIUS = 6378.137;
  RadLatBegin := LatBegin * PI() / 180.0; 
  RadLatEnd = LatEnd * PI() / 180.0; 
  RadLatDiff = RadLatBegin - RadLatEnd; 
  RadLngDiff = LngBegin * PI() / 180.0 - LngEnd * PI() / 180.0;  
  Distance = 2 * ASIN(SQRT(POWER(SIN(RadLatDiff/2), 2)+COS(RadLatBegin)*COS(RadLatEnd)*POWER(SIN(RadLngDiff/2), 2)));
  Distance = Distance * EARTH_RADIUS; 
  RETURN Distance;
END
$$;

alter function sum_lat_long_km(double precision, double precision, double precision, double precision) owner to postgres;

